<?php
//account page language
$_['text_seller_account']  = 'Seller Account';
$_['text_dashboard']  = 'Dashboard';
$_['text_seller_profile']  = 'Seller Profile';
$_['text_seller_products']  = 'Products';
$_['text_seller_orders']  = 'Orders';
$_['text_product_reviews']  = 'Product Reviews';
$_['text_seller_reviews']  = 'My Reviews';
$_['text_seller_earning']  = 'Earning';
$_['text_seller_transactions']  = 'Transactions';
$_['text_payout_request']  = 'Payout Request';
$_['text_category_request']  = 'Category Request';
$_['text_product_import']  = 'Product Import';
$_['text_product_return']  = 'Product Return';
$_['text_coupons']  = 'Coupons';
$_['text_downloads']  = 'Downloads';
$_['text_support_system']  = 'Support System';
$_['text_seller_shipping']  = 'Shipping';
$_['text_seller']  = 'Register as Seller';