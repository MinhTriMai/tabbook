<?php
// Heading
$_['heading_title']     = 'Register As Seller';

// Text
$_['text_account']      = 'Account';
$_['text_seller']       = 'Register as Seller';
$_['text_success']      = 'Success: You have successfully registered as Seller!';

// Entry
$_['entry_seller']      = 'Register as Seller';
