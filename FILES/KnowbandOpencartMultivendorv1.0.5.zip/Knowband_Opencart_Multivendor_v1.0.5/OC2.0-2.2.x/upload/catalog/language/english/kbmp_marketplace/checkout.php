<?php
// Text
$_['text_title']            = 'Marketplace Custom Shipping';
$_['text_weight']           = 'Weight:';
$_['text_marketplace']      = 'Marketplace';