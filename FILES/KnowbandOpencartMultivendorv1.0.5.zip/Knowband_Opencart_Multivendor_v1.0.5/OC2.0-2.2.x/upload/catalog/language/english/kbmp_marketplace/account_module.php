<?php
//register
$_['text_register_seller'] = 'Register as Seller';
$_['entry_seller'] = 'Register as Seller';
$_['link_text_seller_agreement'] = 'Read Seller Agreement';
$_['heading_seller_agreement'] = 'Seller Agreement';
//module account page
$_['text_dashboard']  = 'Dashboard';
$_['text_seller_profile']  = 'Seller Profile';
$_['text_seller_products']  = 'Products';
$_['text_seller_orders']  = 'Orders';
$_['text_product_reviews']  = 'Product Reviews';
$_['text_seller_reviews']  = 'My Reviews';
$_['text_seller_earning']  = 'Earning';
$_['text_seller_transactions']  = 'Transactions';
$_['text_category_request']  = 'Category Request';
$_['text_seller_shipping']  = 'Shipping';
//tracking number
$_['text_tracking_column'] = 'Tracking Number';