<?php

$_['text_support'] = 'Support';
$_['text_knowband_marketplace'] = 'Knowband Marketplace';
$_['text_support_other'] = 'CHECK OTHER POPULAR EXTENSION';
$_['text_support_sc'] = 'One Page Checkout Pro Extension';
$_['text_support_sc_descp'] = 'Converts a multi-step checkout process into a single page checkout.';
$_['text_support_etsy'] = 'Etsy Marketplace Integration';
$_['text_support_etsy_descp'] = 'Integrates your Opencart store with the popular marketplace Etsy';
$_['text_support_ebay'] = 'Ebay - Opencart Integration';
$_['text_support_ebay_descp'] = 'Integrates your Opencart store with the popular marketplace Ebay';
$_['text_support_mab'] = 'Mobile App Builder';
$_['text_support_mab_descp'] = 'Transform your OpenCart site into a mobile app with our services.';
$_['text_support_view_more'] = 'VIEW MORE';
$_['text_support_ticket1'] = 'In case of any issue, ';
$_['text_support_ticket2'] = 'raise a ticket';
$_['text_support_ticket3'] = 'OR email us at support@knowband.com.';
$_['text_click_here'] = 'Click here';
$_['text_user_manual'] = 'for User Manual';

?>