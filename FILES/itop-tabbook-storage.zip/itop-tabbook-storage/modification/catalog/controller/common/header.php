<?php
class ControllerCommonHeader extends Controller {
	public function index() {

			$this->load->model('kbmp_marketplace/kbmp_marketplace');
                        $data['is_seller'] = $this->model_kbmp_marketplace_kbmp_marketplace->is_seller();
			
		// Analytics
		$this->load->model('setting/extension');

		$data['analytics'] = array();

		$analytics = $this->model_setting_extension->getExtensions('analytics');

		foreach ($analytics as $analytic) {
			if ($this->config->get('analytics_' . $analytic['code'] . '_status')) {
				$data['analytics'][] = $this->load->controller('extension/analytics/' . $analytic['code'], $this->config->get('analytics_' . $analytic['code'] . '_status'));
			}
		}

		if ($this->request->server['HTTPS']) {
			$server = $this->config->get('config_ssl');
		} else {
			$server = $this->config->get('config_url');
		}

		if (is_file(DIR_IMAGE . $this->config->get('config_icon'))) {
			$this->document->addLink($server . 'image/' . $this->config->get('config_icon'), 'icon');
		}

		$data['title'] = $this->document->getTitle();

		$data['base'] = $server;
		
			if (isset($this->request->get['route']) && $this->request->get['route'] == 'kbmp_marketplace/sellers') {
                            $this->load->model('setting/kbmp_marketplace');
                            $store_id = (int) $this->config->get('config_store_id');
                            $settings = $this->model_setting_kbmp_marketplace->getSetting('kbmp_marketplace', $store_id);
                            $data['description'] = $settings['kbmp_marketplace_setting']['kbmp_seller_listing_meta_description'];
                        } else {
                            $data['description'] = $this->document->getDescription();
                        }
			
		
			if (isset($this->request->get['route']) && $this->request->get['route'] == 'kbmp_marketplace/sellers') {
                            $this->load->model('setting/kbmp_marketplace');
                            $store_id = (int) $this->config->get('config_store_id');
                            $settings = $this->model_setting_kbmp_marketplace->getSetting('kbmp_marketplace', $store_id);
                            $data['keywords'] = $settings['kbmp_marketplace_setting']['kbmp_seller_listing_meta_keywords'];
                        } else {
                            $data['keywords'] = $this->document->getKeywords();
                        }
			
		$data['links'] = $this->document->getLinks();
		$data['styles'] = $this->document->getStyles();
		$data['scripts'] = $this->document->getScripts('header');
		$data['lang'] = $this->language->get('code');
		$data['direction'] = $this->language->get('direction');

		$data['name'] = $this->config->get('config_name');

		if (is_file(DIR_IMAGE . $this->config->get('config_logo'))) {
			$data['logo'] = $server . 'image/' . $this->config->get('config_logo');
		} else {
			$data['logo'] = '';
		}

		$this->load->language('common/header');

		// Wishlist
		if ($this->customer->isLogged()) {
			$this->load->model('account/wishlist');

			$data['text_wishlist'] = sprintf($this->language->get('text_wishlist'), $this->model_account_wishlist->getTotalWishlist());
		} else {
			$data['text_wishlist'] = sprintf($this->language->get('text_wishlist'), (isset($this->session->data['wishlist']) ? count($this->session->data['wishlist']) : 0));
		}

		$data['text_logged'] = sprintf($this->language->get('text_logged'), $this->url->link('account/account', '', true), $this->customer->getFirstName(), $this->url->link('account/logout', '', true));
		
		$data['home'] = $this->url->link('common/home');
		$data['wishlist'] = $this->url->link('account/wishlist', '', true);
		$data['compare'] = $this->url->link('product/compare', '', true);
		$data['logged'] = $this->customer->isLogged();
		$data['account'] = $this->url->link('account/account', '', true);
		$data['register'] = $this->url->link('account/register', '', true);
		$data['login'] = $this->url->link('account/login', '', true);
		$data['order'] = $this->url->link('account/order', '', true);
		$data['transaction'] = $this->url->link('account/transaction', '', true);
		$data['download'] = $this->url->link('account/download', '', true);
		$data['logout'] = $this->url->link('account/logout', '', true);
		$data['shopping_cart'] = $this->url->link('checkout/cart');
		$data['checkout'] = $this->url->link('checkout/checkout', '', true);
		$data['contact'] = $this->url->link('information/contact');
		$data['telephone'] = $this->config->get('config_telephone');

                        $this->load->language('kbmp_marketplace/header');  
			$this->load->model('setting/kbmp_marketplace');
                        //Get the module configuration values
                        $store_id = (int) $this->config->get('config_store_id');
                        $settings = $this->model_setting_kbmp_marketplace->getSetting('kbmp_marketplace', $store_id);
                        $data['kbmp_marketplace_settings'] = $settings;

                        //Start - Condition added to check if module is enabled - added on 15-Jan-2019 by Harsh
                        if (isset($settings['kbmp_marketplace_setting']['kbmp_module_enable']) && $settings['kbmp_marketplace_setting']['kbmp_module_enable']) {
				$data['text_dashboard'] = $this->language->get('text_dashboard');
                                $data['text_seller_profile'] = $this->language->get('text_seller_profile');
                                $data['text_seller_products'] = $this->language->get('text_products');
                                $data['text_seller_orders'] = $this->language->get('text_orders');
                                $data['text_product_reviews'] = $this->language->get('text_product_reviews');
                                $data['text_seller_reviews'] = $this->language->get('text_seller_reviews');
                                $data['text_seller_earning'] = $this->language->get('text_earning');
                                $data['text_seller_transactions'] = $this->language->get('text_transactions');
                                $data['text_payoutRequest'] = $this->language->get('text_payoutRequest');
                                $data['text_category_request'] = $this->language->get('text_category_request');
                                $data['text_seller_shipping'] = $this->language->get('text_shipping');
                                $data['text_product_return'] = $this->language->get('text_product_return');
                                $data['text_product_import'] = $this->language->get('text_product_import');
                                $data['text_coupons'] = $this->language->get('text_coupons');
                                $data['text_downloads'] = $this->language->get('text_downloads');
                                $data['text_support_system'] = $this->language->get('text_support_system');
                                $data['text_back_to_site'] = $this->language->get('text_back_to_site');
                                $data['text_sellers'] = $this->language->get('text_sellers');
                                $data['text_seller_account'] = $this->language->get('text_seller_account');
		                    
                                $data['sellers'] = $this->url->link('kbmp_marketplace/sellers', '', true);
		                $data['home_link'] = $this->url->link('common/home');
                                $data['dashboard_link'] = $this->url->link('kbmp_marketplace/dashboard');
                                $data['seller_profile_link'] = $this->url->link('kbmp_marketplace/seller_profile');
                                $data['products_link'] = $this->url->link('kbmp_marketplace/products');
                                $data['orders_link'] = $this->url->link('kbmp_marketplace/orders');
                                $data['product_reviews_link'] = $this->url->link('kbmp_marketplace/product_reviews');
                                $data['seller_reviews_link'] = $this->url->link('kbmp_marketplace/seller_reviews');
                                $data['earning_link'] = $this->url->link('kbmp_marketplace/earning');
                                $data['transactions_link'] = $this->url->link('kbmp_marketplace/transactions');
                                $data['payoutRequest_link'] = $this->url->link('kbmp_marketplace/payoutRequest');
                                $data['category_request_link'] = $this->url->link('kbmp_marketplace/category_request');
                                $data['shipping_link'] = $this->url->link('kbmp_marketplace/shipping');
                                $data['product_import_link'] = $this->url->link('kbmp_marketplace/product_import');
                                $data['return_link'] = $this->url->link('kbmp_marketplace/return');
                                $data['coupon_link'] = $this->url->link('kbmp_marketplace/coupon');
                                $data['downloads_link'] = $this->url->link('kbmp_marketplace/download');
                                $data['support_link'] = $this->url->link('kbmp_marketplace/support');
	         	}  
                        $this->load->language('common/header');          
                        //Ends
			
		
		$data['language'] = $this->load->controller('common/language');
		$data['currency'] = $this->load->controller('common/currency');
		
				/* Edit for Search Category Module by OCMod */
				$module_status = $this->config->get('module_ocsearchcategory_status');
				if($module_status) {
					$data['search'] = $this->load->controller('extension/module/ocsearchcategory');
				} else {
					$data['search'] = $this->load->controller('common/search');
				}
				/* End Code */
			
		$data['cart'] = $this->load->controller('common/cart');
		$data['menu'] = $this->load->controller('common/menu');


				$data['block1'] = $this->load->controller('common/block1');
				$data['block2'] = $this->load->controller('common/block2');
				$data['block3'] = $this->load->controller('common/block3');
				$data['block9'] = $this->load->controller('common/block9');				
				$data['block10'] = $this->load->controller('common/block10');
				if($this->config->get('module_ocajaxlogin_status')){
					$data['use_ajax_login'] = true;
				}else{
					$data['use_ajax_login'] = false;
				}
				
				// For page specific css
				if (isset($this->request->get['route'])) {
					if (isset($this->request->get['product_id'])) {
						$class = '-' . $this->request->get['product_id'];
					} elseif (isset($this->request->get['path'])) {
						$class = '-' . $this->request->get['path'];
					} elseif (isset($this->request->get['manufacturer_id'])) {
						$class = '-' . $this->request->get['manufacturer_id'];
					} elseif (isset($this->request->get['information_id'])) {
						$class = '-' . $this->request->get['information_id'];
					} else {
						$class = '';
					}

					$data['class'] = str_replace('/', '-', $this->request->get['route']) . $class;
				} else {
					$data['class'] = 'common-home';
				}
			

        $data['store_id'] = $this->config->get('config_store_id');
        $data['theme_option_status'] = $this->config->get('module_octhemeoption_status');
        $data['a_tag'] = $this->config->get('module_octhemeoption_a_tag');
        $data['header_tag'] = $this->config->get('module_octhemeoption_header_tag');
        $data['body_css'] = $this->config->get('module_octhemeoption_body');
            
		return $this->load->view('common/header', $data);
	}
}
